const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors'); 

const app = express();
const PORT = 3000;

// Conexão com o banco de dados MySQL
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'projetofinal',
});

connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao MySQL:', err);
  } else {
    console.log('Conexão bem-sucedida ao MySQL');
  }
});


app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.get('/', (req, res) => {
  res.send('Bem-vindo à página inicial');
});


app.post('/cadastro', async (req, res) => {
  try {
    const { nome, email, genero, senha } = req.body;

    connection.query('SELECT * FROM Usuário WHERE `E-Mail` = ? ', [email], async (error, results) => {
        if (error) throw error;
  
        if (results.length > 0) {
          res.status(200).send(); 
        }
    });

    connection.query(
      'INSERT INTO Usuário (`ds_nome`, `E-Mail`, `Genêro`, `senha`) VALUES (?, ?, ?, ?)',
      [nome, email, genero, senha],
      (error, results) => {
        if (error) throw error;
        res.status(200).send();
      }
    );
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro interno do servidor');
  }
});

app.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;

    connection.query('SELECT * FROM Usuário WHERE `E-Mail` = ? AND `senha` = ?', [email, senha], async (error, results) => {
      if (error) throw error;

      if (results.length > 0) {
        res.status(200).send(); 
      } else {
        res.status(401).send('Credenciais inválidas'); 
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro interno do servidor');
  }
});

// Inicialização do servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
