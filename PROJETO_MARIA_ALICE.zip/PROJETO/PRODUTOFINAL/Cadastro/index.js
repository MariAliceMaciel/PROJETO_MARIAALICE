  const formCadastro = document.getElementById('formCadastro');
  formCadastro.addEventListener('submit', async (e) => {
    e.preventDefault();
    const firstname = document.getElementById('firstname').value;
    const lastname = document.getElementById('lastname').value;
    const email = document.getElementById('email').value;
    const number = document.getElementById('number').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const gender = document.querySelector('input[name="gender"]:checked') ? document.querySelector('input[name="gender"]:checked').value : null;

    if (password !== confirmPassword) {
      alert('As senhas não coincidem');
      return;
    }

    try {
      const response = await fetch('http://localhost:3000/cadastro', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nome: firstname + ' ' + lastname,
          email: email,
          numero: number,
          senha: password,
          genero: gender,
        }),
      });

      const status = await response.status;

      if (status === 200) {
        window.location.href = '../Login1/index.html';
      } else {
        alert('Erro ao cadastrar');
      }
    } catch (error) {
      console.error('Erro:', error);
    }
  });
