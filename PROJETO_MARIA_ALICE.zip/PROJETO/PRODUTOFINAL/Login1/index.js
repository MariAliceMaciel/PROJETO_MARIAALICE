const formLogin = document.querySelector(".formLogin");

formLogin.addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = formLogin.querySelector('input[type="email"]').value;
  const password = formLogin.querySelector('input[type="password"]').value;

  try {
    const response = await fetch("http://localhost:3000/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email: email, senha: password }),
    });

    const status = await response.status;

      if (status === 200) {
        window.location.href = '../DICIONÁRIO/index.html';
        localStorage.setItem('usuario', email);
      } else {
        alert('Credenciais inválidas');
      }
  } catch (error) {
    console.error("Erro:", error);
  }
});
